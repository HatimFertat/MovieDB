package com.scalar.db.storage.cassandra;

public class CassandraConfig {
  // just hold the storage name for consistency with other storage
  public static final String STORAGE_NAME = "cassandra";
}
