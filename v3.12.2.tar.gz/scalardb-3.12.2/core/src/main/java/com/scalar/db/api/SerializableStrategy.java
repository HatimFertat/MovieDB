package com.scalar.db.api;

/** @deprecated As of release 3.2.0. Will be removed in release 5.0.0 */
@Deprecated
public interface SerializableStrategy {}
