package com.scalar.db.storage.jdbc;

public enum KeyType {
  PARTITION,
  CLUSTERING
}
