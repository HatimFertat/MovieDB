package com.scalar.db.common;

public interface DistributedTransactionDecoratorAddable {

  void addTransactionDecorator(DistributedTransactionDecorator transactionDecorator);
}
