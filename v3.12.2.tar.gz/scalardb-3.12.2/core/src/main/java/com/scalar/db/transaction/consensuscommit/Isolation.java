package com.scalar.db.transaction.consensuscommit;

public enum Isolation {
  SNAPSHOT,
  SERIALIZABLE,
}
